# tvf_app/test_requests/forms.py

from django import forms
from django.forms import inlineformset_factory
from.models import (
    TestRequest, Customer, Project, TVFType, TVFEnvironment, TVFStatus,
    PlasticCodeLookup, DispatchMethod, TestRequestPhaseDefinition,
    TestRequestPlasticCode, TestRequestInputFile, TestRequestPAN,
    TestRequestQuality, TestRequestShipping, RejectReason, TrustportFolder
)
from django.contrib.auth.models import User # For TVF Initiator dropdown
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm, UserChangeForm

# Use Django's built-in UserCreationForm for simplicity
# You can customize it later if you need more fields than username/password
class CustomUserCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = get_user_model()
        # Include 'email' if you want it on the registration form
        fields = UserCreationForm.Meta.fields + ('email',)

class TestRequestForm(forms.ModelForm):
    """
    Main form for creating and updating TestRequest instances.
    """
    # Override fields to use specific widgets or querysets if needed
    customer = forms.ModelChoiceField(
        queryset=Customer.objects.all().order_by('name'),
        empty_label="Select Customer",
        help_text="Select the customer for this TVF."
    )
    project = forms.ModelChoiceField(
        queryset=Project.objects.none(), # Initially empty, populated by JS
        empty_label="Select Project",
        help_text="Select the project for this TVF. (Note: Projects are linked to Customers and Environments)"
    )
    tvf_type = forms.ModelChoiceField(
        queryset=TVFType.objects.all().order_by('name'),
        empty_label="Select TVF Type",
        help_text="Select the type of TVF."
    )
    tvf_environment = forms.ModelChoiceField(
        queryset=TVFEnvironment.objects.all().order_by('name'),
        empty_label="Select TVF Environment",
        help_text="Select the environment for this TVF."
    )
    tvf_initiator = forms.ModelChoiceField(
        queryset=User.objects.filter(is_active=True).order_by('username'),
        empty_label="Select Initiator",
        help_text="Select the user who initiated this TVF."
    )
    status = forms.ModelChoiceField(
        queryset=TVFStatus.objects.all().order_by('name'),
        empty_label="Select Status",
        help_text="Select the current status of the TVF."
    )
    current_phase = forms.ModelChoiceField(
        queryset=TestRequestPhaseDefinition.objects.all().order_by('order'),
        empty_label="Select Current Phase",
        required=False, # Can be null initially, or set by default in model save
        help_text="Select the current phase of the TVF lifecycle."
    )

    request_received_date = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        help_text="Date and time when the request was received."
    )

    # Trustport Folder (will be dynamic)
    trustport_folder_actual = forms.ModelChoiceField(
        queryset=TrustportFolder.objects.none(), # Initially empty, populated by JS
        empty_label="Select Trustport Folder",
        required=False, # Can be null if not applicable or chosen later
        help_text="Actual Trustport folder used for this specific TVF."
    )

    # Dispatch Method (will be dynamic)
    dispatch_method_for_form = forms.ModelChoiceField( # Renamed to avoid conflict with TestRequestShippingForm
        queryset=DispatchMethod.objects.none(), # Initially empty, populated by JS
        empty_label="Select Dispatch Method",
        required=False, # Can be null if not applicable or chosen later
        help_text="Default dispatch method for this TVF (will be filtered by Customer/Project)."
    )

    class Meta:
        model = TestRequest
        fields = [
            # General Info
            'cr_number', 'customer', 'project', 'tvf_name', 'tvf_initiator',
            'tvf_type', 'tvf_environment', 'tvf_pin_mailer', 'run_today', # <--- Add run_today

            # Dates
            'request_received_date', 'request_ship_date', # 'date_created' is auto_now_add

            # Codes & Comments
            's_code', 'd_code', 'comments', 'tester_comments',

            # Configuration Versions
            'pres_config_version', 'proc_config_version', 'pin_config_version',
            # 'trustport_folder_actual' is now a ModelChoiceField above
        ]
        # Exclude auto-generated fields like tvf_number, date_created, last_status_update
        # as they are handled by signals or auto_now_add/auto_now.
        # We will handle quality and shipping details via OneToOne forms below.

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Apply form-control class to all text/select/number/date inputs
        for field_name, field in self.fields.items():
            if isinstance(field.widget, (forms.TextInput, forms.Textarea, forms.Select, forms.EmailInput, forms.NumberInput, forms.DateTimeInput)):
                field.widget.attrs.update({'class': 'form-control'})
            elif isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs.update({'class': 'form-check-input'})

        # Initial queryset for project, trustport_folder_actual, dispatch_method_for_form will be empty
        # They will be populated via JavaScript/AJAX based on customer/project selection.
        # If an instance is provided (for update view), populate the fields with existing data.
        if self.instance.pk:
            if self.instance.customer:
                self.fields['project'].queryset = Project.objects.filter(customer=self.instance.customer).order_by('name')
                self.fields['trustport_folder_actual'].queryset = TrustportFolder.objects.filter(
                    customer=self.instance.customer, project=self.instance.project
                ).order_by('folder_path')
                self.fields['dispatch_method_for_form'].queryset = DispatchMethod.objects.filter(
                    customer=self.instance.customer, project=self.instance.project
                ).order_by('name')

# --- Inline Formsets for Related Models ---

# --- TestRequestPlasticCodeForm (adjust plastic_code_lookup queryset) ---
class TestRequestPlasticCodeForm(forms.ModelForm):
    plastic_code_lookup = forms.ModelChoiceField(
        queryset=PlasticCodeLookup.objects.none(), # Initially empty, populated by JS
        empty_label="Select Plastic Code",
        help_text="Select the plastic code."
    )
    class Meta:
        model = TestRequestPlasticCode
        fields = ['plastic_code_lookup', 'quantity', 'thermal_colour']
        widgets = {
            'quantity': forms.NumberInput(attrs={'class': 'form-control'}),
            'thermal_colour': forms.TextInput(attrs={'class': 'form-control'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            if isinstance(field.widget, (forms.TextInput, forms.Textarea, forms.Select, forms.EmailInput, forms.NumberInput)):
                field.widget.attrs.update({'class': 'form-control'})
            elif isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs.update({'class': 'form-check-input'})

# --- TestRequestInputFileForm (no major changes needed here based on current requirements) ---
class TestRequestInputFileForm(forms.ModelForm):
    class Meta:
        model = TestRequestInputFile
        fields = ['file_name', 'date_file_received', 'card_co', 'card_wo', 'card_qty', 'pin_co', 'pin_wo', 'pin_qty']
        widgets = {
            'file_name': forms.TextInput(attrs={'class': 'form-control'}),
            'date_file_received': forms.DateTimeInput(attrs={'type': 'datetime-local', 'class': 'form-control'}),
            'card_co': forms.TextInput(attrs={'class': 'form-control'}),
            'card_wo': forms.TextInput(attrs={'class': 'form-control'}),
            'card_qty': forms.NumberInput(attrs={'class': 'form-control'}),
            'pin_co': forms.TextInput(attrs={'class': 'form-control'}),
            'pin_wo': forms.TextInput(attrs={'class': 'form-control'}),
            'pin_qty': forms.NumberInput(attrs={'class': 'form-control'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            if isinstance(field.widget, (forms.TextInput, forms.Textarea, forms.Select, forms.EmailInput, forms.NumberInput, forms.DateTimeInput)):
                field.widget.attrs.update({'class': 'form-control'})
            elif isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs.update({'class': 'form-check-input'})

# --- TestRequestPANForm (no changes needed here) ---
class TestRequestPANForm(forms.ModelForm):
    class Meta:
        model = TestRequestPAN
        fields = ['pan_truncated', 'is_available']
        widgets = {
            'pan_truncated': forms.TextInput(attrs={'class': 'form-control'}),
            'is_available': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            if isinstance(field.widget, (forms.TextInput, forms.Textarea, forms.Select, forms.EmailInput, forms.NumberInput)):
                field.widget.attrs.update({'class': 'form-control'})
            elif isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs.update({'class': 'form-check-input'})

# --- TestRequestQualityForm (no changes needed here for now) ---
class TestRequestQualityForm(forms.ModelForm):
    quality_sign_off_by = forms.ModelChoiceField(
        queryset=User.objects.filter(is_active=True).order_by('username'),
        empty_label="Select Sign-off User",
        required=False,
        help_text="User who signed off on quality."
    )
    class Meta:
        model = TestRequestQuality
        fields = ['output_accordance_request', 'checked_against_specifications', 'quality_sign_off_by', 'quality_sign_off_date']
        widgets = {
            'output_accordance_request': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'checked_against_specifications': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'quality_sign_off_date': forms.DateTimeInput(attrs={'type': 'datetime-local', 'class': 'form-control'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            if isinstance(field.widget, (forms.TextInput, forms.Textarea, forms.Select, forms.EmailInput, forms.NumberInput, forms.DateTimeInput)):
                field.widget.attrs.update({'class': 'form-control'})
            elif isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs.update({'class': 'form-check-input'})

# --- TestRequestShippingForm (add tracking_number field) ---
class TestRequestShippingForm(forms.ModelForm):
    # dispatch_method will be set by the view or filtered dynamically
    dispatch_method = forms.ModelChoiceField(
        queryset=DispatchMethod.objects.all().order_by('name'), # This will be filtered dynamically later
        empty_label="Select Dispatch Method",
        required=False,
        help_text="Method of dispatch."
    )
    shipping_sign_off_by = forms.ModelChoiceField(
        queryset=User.objects.filter(is_active=True).order_by('username'),
        empty_label="Select Sign-off User",
        required=False,
        help_text="User who signed off on shipping."
    )
    class Meta:
        model = TestRequestShipping
        fields = ['dispatch_method', 'shipping_sign_off_by', 'date_shipped', 'ship_to_address', 'tracking_number'] # <--- Add tracking_number
        widgets = {
            'ship_to_address': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'date_shipped': forms.DateTimeInput(attrs={'type': 'datetime-local', 'class': 'form-control'}),
            'tracking_number': forms.TextInput(attrs={'class': 'form-control'}), # <--- Add widget for tracking_number
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            if isinstance(field.widget, (forms.TextInput, forms.Textarea, forms.Select, forms.EmailInput, forms.NumberInput, forms.DateTimeInput)):
                field.widget.attrs.update({'class': 'form-control'})
            elif isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs.update({'class': 'form-check-input'})


# --- Inline Formset Factories ---
# These factories will be used in the views to create multiple forms for related objects.

PlasticCodeFormSet = inlineformset_factory(
    TestRequest, TestRequestPlasticCode, form=TestRequestPlasticCodeForm,
    extra=1, can_delete=True
)

InputFileFormSet = inlineformset_factory(
    TestRequest, TestRequestInputFile, form=TestRequestInputFileForm,
    extra=1, can_delete=True
)

# Note: PANs are related to InputFile, not directly to TestRequest.
# We'll handle PANs as nested inlines or separately if needed.
# For simplicity in the main TVF form, we'll keep PANs as a separate formset for now,
# or manage them via the TestRequestInputFile detail view if we build one.
# For now, we'll create a formset factory for PANs directly related to InputFile.
# If you want to add PANs directly when creating a TVF, it gets more complex (nested formsets).
# Let's assume PANs are added/edited via the InputFile entry itself, or we simplify.
# For the main TVF form, we'll focus on the direct children.

# If you want to manage PANs directly from the TestRequest form, it requires nested formsets,
# which adds significant complexity. For a clean start, we'll assume PANs are managed
# either via a separate view for TestRequestInputFile details, or we simplify the input.
# For now, we won't include PANs directly in the main TestRequest form's inline formsets.
# If you explicitly need nested formsets, let me know, but it's a bigger step.

# For Quality and Shipping, since they are OneToOne, they are not handled by inlineformset_factory
# in the same way. They will be handled as separate forms in the view.