# tvf_app/test_requests/views.py
from django.urls import reverse_lazy
from django.views.generic.edit import FormView
from django.contrib import messages # For success/error messages
from .forms import CustomUserCreationForm # Import your custom form
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages # For user feedback messages
from django.db import transaction # For atomic database operations
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin # If using Class-Based Views
from django.utils.decorators import method_decorator
from datetime import timedelta

# Import your models and forms
from.models import (
    TestRequest, Customer, Project, TVFType, TVFEnvironment, TVFStatus,
    PlasticCodeLookup, DispatchMethod, TestRequestPhaseDefinition,
    TestRequestPlasticCode, TestRequestInputFile, TestRequestPAN,
    TestRequestQuality, TestRequestShipping
)
from.forms import (
    TestRequestForm, TestRequestPlasticCodeForm, TestRequestInputFileForm,
    TestRequestPANForm, TestRequestQualityForm, TestRequestShippingForm,
    PlasticCodeFormSet, InputFileFormSet
)

# For PDF generation
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa # Import the pisa converter

# --- Helper function for rendering PDF ---
def render_to_pdf(template_src, context_dict={}):
    template = get_template(template_src)
    html = template.render(context_dict)
    response = HttpResponse(content_type='application/pdf')
    response = 'attachment; filename="test_request.pdf"' # Forces download
    # response = 'inline; filename="test_request.pdf"' # Displays in browser
    pisa_status = pisa.CreatePDF(
        html, dest=response)
    if pisa_status.err:
        return HttpResponse('We had some errors <pre>' + html + '</pre>')
    return response

# New Registration View
class RegisterView(FormView):
    template_name = 'registration/register.html'
    form_class = CustomUserCreationForm # Use the form you just created
    success_url = reverse_lazy('login') # Redirect to login page after successful registration

    def form_valid(self, form):
        form.save()
        messages.success(self.request, 'Account created successfully! Please log in.')
        return super().form_valid(form)

    def form_invalid(self, form):
        # Form errors are automatically handled by Django if {{ form.as_p }} is used
        # You can add a general error message if you like
        messages.error(self.request, 'There was an error with your registration. Please check the form.')
        return super().form_invalid(form)

# --- Helper functions for group checks (from previous steps) ---
def is_project_manager(user):
    return user.groups.filter(name='Project Managers').exists()

def is_npi_user(user):
    return user.groups.filter(name='NPI Users').exists()

def is_quality_user(user):
    return user.groups.filter(name='Quality Users').exists()

def is_logistics_user(user):
    return user.groups.filter(name='Logistics Users').exists()

def is_coach(user):
    return user.groups.filter(name='Coaches').exists()

def can_view_dashboard(user):
    return is_project_manager(user) or is_npi_user(user) or \
           is_quality_user(user) or is_logistics_user(user) or \
           is_coach(user) or user.is_superuser # Superusers always have access

# --- AJAX Views for Dynamic Dropdowns ---
from django.http import JsonResponse

@login_required
def get_filtered_projects(request):
    customer_id = request.GET.get('customer_id')
    projects = []
    if customer_id:
        projects = list(Project.objects.filter(customer_id=customer_id).values('id', 'name').order_by('name'))
    return JsonResponse({'projects': projects})

@login_required
def get_filtered_plastic_codes(request):
    customer_id = request.GET.get('customer_id')
    project_id = request.GET.get('project_id')
    plastic_codes = []
    if customer_id and project_id:
        plastic_codes = list(PlasticCodeLookup.objects.filter(
            customer_id=customer_id, project_id=project_id
        ).values('id', 'code').order_by('code'))
    return JsonResponse({'plastic_codes': plastic_codes})

@login_required
def get_filtered_trustport_folders(request):
    customer_id = request.GET.get('customer_id')
    project_id = request.GET.get('project_id')
    folders = []
    if customer_id and project_id:
        folders = list(TrustportFolder.objects.filter(
            customer_id=customer_id, project_id=project_id
        ).values('id', 'folder_path').order_by('folder_path'))
    return JsonResponse({'folders': folders})

@login_required
def get_filtered_dispatch_methods(request):
    customer_id = request.GET.get('customer_id')
    project_id = request.GET.get('project_id')
    methods = []
    if customer_id and project_id:
        methods = list(DispatchMethod.objects.filter(
            customer_id=customer_id, project_id=project_id
        ).values('id', 'name').order_by('name'))
    return JsonResponse({'methods': methods})

@login_required
def get_sla_and_calculate_ship_date(request):
    received_date_str = request.GET.get('received_date')
    customer_id = request.GET.get('customer_id')
    ship_date = None

    if received_date_str and customer_id:
        try:
            received_date = timezone.datetime.fromisoformat(received_date_str)
            customer = Customer.objects.get(pk=customer_id)
            sla_days = customer.sla_days

            # Calculate ship date: received_date + sla_days
            calculated_ship_date = received_date + timedelta(days=sla_days)
            ship_date = calculated_ship_date.isoformat(timespec='minutes') # Format for datetime-local input
        except (ValueError, Customer.DoesNotExist) as e:
            print(f"Error calculating ship date: {e}") # For debugging
            pass # ship_date remains None

    return JsonResponse({'ship_date': ship_date})

# --- Coach View: Dashboard of ALL OPEN TVFs ---
@login_required
@user_passes_test(can_view_dashboard, login_url='test_requests:access_denied')
def coach_dashboard(request):
    # 'Open' TVFs could be anything not 'Completed' or 'Rejected'
    # You'll need to define what constitutes an "open" status based on your TVFStatus model
    open_statuses = TVFStatus.objects.exclude(name__in=['Completed', 'Rejected']).values_list('name', flat=True)
    open_tvfs = TestRequest.objects.filter(status__name__in=open_statuses).order_by('-date_created')

    context = {
        'open_tvfs': open_tvfs,
        'role': 'Coach Dashboard',
        'is_project_manager': is_project_manager(request.user),
        'is_npi_user': is_npi_user(request.user),
        'is_quality_user': is_quality_user(request.user),
        'is_logistics_user': is_logistics_user(request.user),
        'is_coach': is_coach(request.user),
    }
    return render(request, 'test_requests/coach_dashboard.html', context)

# Any user allowed to view the Coach dashboard
def can_view_dashboard(user):
    return is_project_manager(user) or is_npi_user(user) or \
           is_quality_user(user) or is_logistics_user(user) or \
           is_coach(user) or user.is_superuser # Superusers always have access

# --- Registration View (if you're using this) ---
class RegisterView(FormView):
    template_name = 'registration/register.html'
    form_class = CustomUserCreationForm
    success_url = reverse_lazy('login')

    def form_valid(self, form):
        form.save()
        messages.success(self.request, 'Account created successfully! Please log in.')
        return super().form_valid(form)

    def form_invalid(self, form):
        messages.error(self.request, 'There was an error with your registration. Please check the form.')
        return super().form_invalid(form)

# --- Project Manager View: Create TVF ---
@login_required
@user_passes_test(is_project_manager, login_url='test_requests:access_denied')
def create_tvf_view(request):
    if request.method == 'POST':
        form = TestRequestForm(request.POST)
        plastic_formset = PlasticCodeFormSet(request.POST, prefix='plastic_codes')
        input_file_formset = InputFileFormSet(request.POST, prefix='input_files')

        # Note: TestRequestQualityForm and TestRequestShippingForm are OneToOne,
        # so they are typically handled on update views or as separate forms,
        # not usually part of the initial creation formset unless specifically designed.
        # For PM create, we'll assume they are not filled initially.

        if form.is_valid() and plastic_formset.is_valid() and input_file_formset.is_valid():
            try:
                with transaction.atomic():
                    test_request = form.save(commit=False)
                    test_request.tvf_initiator = request.user

                    # Set initial status and current phase based on your new workflow:
                    # PM initiates TVF, upon submission, it moves to TVF_SUBMITTED phase (NPI's queue)
                    initial_status_pm, _ = TVFStatus.objects.get_or_create(name='TVF_INITITATED_AT_SOURCE')
                    submitted_to_npi_phase, _ = TestRequestPhaseDefinition.objects.get_or_create(name='TVF_SUBMITTED', order=2)

                    test_request.status = initial_status_pm
                    test_request.current_phase = submitted_to_npi_phase
                    test_request.save()

                    # After initial save, update status to 'TVF_SUBMITTED'
                    submitted_status, _ = TVFStatus.objects.get_or_create(name='TVF_SUBMITTED')
                    test_request.status = submitted_status
                    test_request.save(update_fields=['status'])

                    # Save inline formset data
                    plastic_formset.instance = test_request
                    plastic_formset.save()

                    input_file_formset.instance = test_request
                    input_file_formset.save()

                messages.success(request, f"TVF {test_request.tvf_number} created and submitted to NPI!")
                return redirect('test_requests:coach_dashboard')
            except Exception as e:
                messages.error(request, f"Error creating Test Request: {e}")
                import traceback
                traceback.print_exc()
        else:
            messages.error(request, "Please correct the errors below.")
            # If form or formsets are invalid, they will contain errors and be re-rendered
    else:
        # Initial GET request
        form = TestRequestForm(initial={'tvf_initiator': request.user})
        plastic_formset = PlasticCodeFormSet(prefix='plastic_codes')
        input_file_formset = InputFileFormSet(prefix='input_files')

    context = {
        'form': form,
        'plastic_formset': plastic_formset,
        'input_file_formset': input_file_formset,
        'role': 'Project Manager - Create TVF'
    }
    return render(request, 'test_requests/pm_create_tvf.html', context)

# --- NPI View: Update Data Processing Status ---
@login_required
@user_passes_test(is_npi_user, login_url='test_requests:access_denied')
def npi_update_tvf_view(request, tvf_id):
    tvf = get_object_or_404(TestRequest, pk=tvf_id)

    # Check if TVF is in NPI's queue (e.g., 'TVF Released' or 'Rejected to NPI')
    if not (tvf.status.name == 'TVF Released' or tvf.status.name == 'Rejected to NPI' or tvf.current_phase.name == 'NPI Data Processing'):
        messages.warning(request, f"TVF {tvf.tvf_number} is not in your NPI queue for editing.")
        return redirect('test_requests:coach_dashboard')

    if request.method == 'POST':
        action = request.POST.get('action') # To differentiate between 'process' and 'reject'
        comments = request.POST.get('comments', tvf.comments)

        if action == 'process':
            # Update status to 'TVF Data Processed' and move to 'Quality Validation' phase
            tvf.status, _ = TVFStatus.objects.get_or_create(name='TVF Data Processed')
            tvf.current_phase, _ = TestRequestPhaseDefinition.objects.get_or_create(name='Quality Validation')
            tvf.comments = comments
            tvf.is_rejected = False # Ensure it's not marked as rejected if processed
            tvf.save()
            messages.success(request, f"TVF {tvf.tvf_number} processed by NPI and moved to Quality queue!")
            return redirect('test_requests:coach_dashboard')
        
        elif action == 'reject':
            return redirect('test_requests:reject_tvf', tvf_id=tvf.pk) # Redirect to generic reject view
        
    return render(request, 'test_requests/npi_update_tvf.html', {'tvf': tvf, 'role': 'NPI User'})

# --- Quality View: Update Validation Status ---
@login_required
@user_passes_test(is_quality_user, login_url='test_requests:access_denied')
def quality_update_tvf_view(request, tvf_id):
    tvf = get_object_or_404(TestRequest, pk=tvf_id)

    # Check if TVF is in Quality's queue (e.g., 'TVF Data Processed' or 'Rejected to Quality')
    if not (tvf.status.name == 'TVF Data Processed' or tvf.status.name == 'Rejected to Quality' or tvf.current_phase.name == 'Quality Validation'):
        messages.warning(request, f"TVF {tvf.tvf_number} is not in your Quality queue for editing.")
        return redirect('test_requests:coach_dashboard')

    if request.method == 'POST':
        action = request.POST.get('action')
        comments = request.POST.get('comments', tvf.comments)

        if action == 'process':
            # Update status to 'Validation Done' and move to 'Logistics Dispatch' phase
            tvf.status, _ = TVFStatus.objects.get_or_create(name='Validation Done')
            tvf.current_phase, _ = TestRequestPhaseDefinition.objects.get_or_create(name='Logistics Dispatch')
            tvf.comments = comments
            tvf.is_rejected = False
            tvf.save()
            messages.success(request, f"TVF {tvf.tvf_number} validated by Quality and moved to Logistics queue!")
            return redirect('test_requests:coach_dashboard')
        
        elif action == 'reject':
            return redirect('test_requests:reject_tvf', tvf_id=tvf.pk)

    return render(request, 'test_requests/quality_update_tvf.html', {'tvf': tvf, 'role': 'Quality User'})

# --- Logistics View: Update Tracking Number ---
@login_required
@user_passes_test(is_logistics_user, login_url='test_requests:access_denied')
def logistics_update_tvf_view(request, tvf_id):
    tvf = get_object_or_404(TestRequest, pk=tvf_id)

    # Check if TVF is in Logistics' queue (e.g., 'Validation Done' or 'Rejected to Logistics')
    if not (tvf.status.name == 'Validation Done' or tvf.status.name == 'Rejected to Logistics' or tvf.current_phase.name == 'Logistics Dispatch'):
        messages.warning(request, f"TVF {tvf.tvf_number} is not in your Logistics queue for editing.")
        return redirect('test_requests:coach_dashboard')

    if request.method == 'POST':
        action = request.POST.get('action')
        comments = request.POST.get('comments', tvf.comments)
        tracking_number = request.POST.get('tracking_number', '') # Assuming you add this field to TestRequest

        if action == 'process':
            # Update status to 'Shipped'
            tvf.status, _ = TVFStatus.objects.get_or_create(name='Shipped')
            # Once shipped, you might set current_phase to null or a 'Completed' phase
            tvf.current_phase = None # Or a 'Completed' phase definition
            tvf.comments = comments
            # tvf.tracking_number = tracking_number # Uncomment if you add this field to TestRequest model
            tvf.is_rejected = False
            tvf.save()
            messages.success(request, f"TVF {tvf.tvf_number} shipped by Logistics!")
            return redirect('test_requests:coach_dashboard')
        
        elif action == 'reject':
            return redirect('test_requests:reject_tvf', tvf_id=tvf.pk)

    return render(request, 'test_requests/logistics_update_tvf.html', {'tvf': tvf, 'role': 'Logistics User'})

# --- Common Rejection View ---
@login_required
def reject_tvf_view(request, tvf_id):
    tvf = get_object_or_404(TestRequest, pk=tvf_id)

    # Only users from PM, NPI, Quality, Logistics, Coach (or Superuser) can reject
    # Check if the user is part of any of the groups that can reject
    if not (is_project_manager(request.user) or is_npi_user(request.user) or \
            is_quality_user(request.user) or is_logistics_user(request.user) or \
            is_coach(request.user) or request.user.is_superuser):
        messages.error(request, "You do not have permission to reject TVFs.")
        return redirect('test_requests:coach_dashboard') # Redirect to dashboard

    # Prevent rejection if TVF is already completed/shipped
    if tvf.status.name in ['Shipped', 'Completed']:
        messages.error(request, f"TVF {tvf.tvf_number} cannot be rejected as it is already {tvf.status.name}.")
        return redirect('test_requests:coach_dashboard')

    if request.method == 'POST':
        target_phase_name = request.POST.get('target_phase')
        rejection_comments = request.POST.get('comments')
        reject_reason_id = request.POST.get('reject_reason') # Get ID from dropdown

        # Validate inputs
        if not target_phase_name or not rejection_comments:
            messages.error(request, "Please select a target phase and provide rejection comments.")
            # Re-render form with errors if needed
            available_phases = TestRequestPhaseDefinition.objects.all().order_by('order')
            reject_reasons = RejectReason.objects.all().order_by('reason')
            return render(request, 'test_requests/reject_tvf.html', {
                'tvf': tvf,
                'available_phases': available_phases,
                'reject_reasons': reject_reasons,
                'role': 'Reject TVF'
            })

        try:
            # Map target phase to new status name for rejection
            # This mapping makes the status reflect the queue it's rejected TO
            status_map = {
                'Project Manager': 'Rejected to PM',
                'NPI Data Processing': 'Rejected to NPI',
                'Quality Validation': 'Rejected to Quality',
                'Logistics Dispatch': 'Rejected to Logistics',
            }
            new_status_name = status_map.get(target_phase_name, 'Rejected') # Default to 'Rejected'

            target_status, _ = TVFStatus.objects.get_or_create(name=new_status_name)
            target_phase = TestRequestPhaseDefinition.objects.get(name=target_phase_name)
            reject_reason_obj = RejectReason.objects.get(pk=reject_reason_id) if reject_reason_id else None
            
            # Update TVF fields for rejection
            tvf.status = target_status
            tvf.current_phase = target_phase
            tvf.comments = f"REJECTED by {request.user.username} to {target_phase_name}: {rejection_comments}"
            
            # Set the rejection specific fields in TestRequest model
            tvf.is_rejected = True
            tvf.rejected_by = request.user
            tvf.rejected_reason = reject_reason_obj
            tvf.rejected_comments = rejection_comments
            tvf.rejected_date = timezone.now() # Use timezone.now() for datetime
            
            tvf.save()
            messages.success(request, f"TVF {tvf.tvf_number} rejected to {target_phase_name} successfully!")
            return redirect('test_requests:coach_dashboard')
        
        except TestRequestPhaseDefinition.DoesNotExist:
            messages.error(request, "Invalid target phase selected for rejection.")
        except RejectReason.DoesNotExist:
            messages.error(request, "Invalid rejection reason selected.")
        except Exception as e:
            messages.error(request, f"An unexpected error occurred during rejection: {e}")

    # For GET request or if form submission fails
    # Get available phases for rejection dropdown (e.g., only phases *before* current phase, or all relevant)
    available_phases = TestRequestPhaseDefinition.objects.all().order_by('order')
    reject_reasons = RejectReason.objects.all().order_by('reason') # Get all reject reasons

    return render(request, 'test_requests/reject_tvf.html', {
        'tvf': tvf,
        'available_phases': available_phases,
        'reject_reasons': reject_reasons,
        'role': 'Reject TVF'
    })


# --- Access Denied Page ---
def access_denied_view(request):
    return render(request, 'test_requests/access_denied.html')

# --- Views ---

@login_required # Requires user to be logged in to access this view
def test_request_create_view(request):
    """
    View for creating a new Test Request.
    Handles the main form and inline formsets for related data.
    """
    if request.method == 'POST':
        form = TestRequestForm(request.POST)
        plastic_formset = PlasticCodeFormSet(request.POST, prefix='plastic_codes')
        input_file_formset = InputFileFormSet(request.POST, prefix='input_files')
        quality_form = TestRequestQualityForm(request.POST, prefix='quality')
        shipping_form = TestRequestShippingForm(request.POST, prefix='shipping')

        # Validate all forms and formsets
        if (form.is_valid() and plastic_formset.is_valid() and
                input_file_formset.is_valid() and quality_form.is_valid() and
                shipping_form.is_valid()):
            try:
                with transaction.atomic(): # Ensure all saves are atomic
                    test_request = form.save(commit=False)
                    test_request.tvf_initiator = request.user # Set initiator to current logged-in user
                    test_request.save() # Save the main TestRequest object

                    # Save inline formset data
                    plastic_formset.instance = test_request
                    plastic_formset.save()

                    input_file_formset.instance = test_request
                    input_file_formset.save()

                    # Save OneToOne forms
                    quality = quality_form.save(commit=False)
                    quality.test_request = test_request
                    quality.save()

                    shipping = shipping_form.save(commit=False)
                    shipping.test_request = test_request
                    shipping.save()

                messages.success(request, f"Test Request {test_request.tvf_number} created successfully!")
                return redirect('test_requests:detail', pk=test_request.pk) # Redirect to detail page
            except Exception as e:
                messages.error(request, f"Error creating Test Request: {e}")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        # Initial GET request: display empty forms
        form = TestRequestForm(initial={'tvf_initiator': request.user}) # Pre-fill initiator
        plastic_formset = PlasticCodeFormSet(prefix='plastic_codes')
        input_file_formset = InputFileFormSet(prefix='input_files')
        quality_form = TestRequestQualityForm(prefix='quality')
        shipping_form = TestRequestShippingForm(prefix='shipping')

    context = {
        'form': form,
        'plastic_formset': plastic_formset,
        'input_file_formset': input_file_formset,
        'quality_form': quality_form,
        'shipping_form': shipping_form,
    }
    return render(request, 'test_requests/test_request_form.html', context)

@login_required
def test_request_list_view(request):
    """
    View for listing all Test Requests.
    """
    test_requests = TestRequest.objects.all().select_related('customer', 'project', 'tvf_initiator', 'status').order_by('-tvf_number')
    context = {
        'test_requests': test_requests
    }
    return render(request, 'test_requests/test_request_list.html', context)

@login_required
def test_request_detail_view(request, pk):
    """
    View for displaying details of a single Test Request.
    """
    test_request = get_object_or_404(TestRequest.objects.select_related(
        'customer', 'project', 'tvf_initiator', 'tvf_type', 'tvf_environment', 'status', 'current_phase'
    ).prefetch_related(
        'plastic_codes_entries__plastic_code_lookup',
        'input_files_entries__pans',
        'quality_details',
        'shipping_details__dispatch_method'
    ), pk=pk)

    context = {
        'test_request': test_request
    }
    return render(request, 'test_requests/test_request_detail.html', context)

@login_required
def test_request_update_view(request, pk):
    """
    View for updating an existing Test Request.
    """
    test_request = get_object_or_404(TestRequest, pk=pk)

    # Get or create related OneToOne objects for quality and shipping
    quality_instance, created_quality = TestRequestQuality.objects.get_or_create(test_request=test_request)
    shipping_instance, created_shipping = TestRequestShipping.objects.get_or_create(test_request=test_request)

    if request.method == 'POST':
        form = TestRequestForm(request.POST, instance=test_request)
        plastic_formset = PlasticCodeFormSet(request.POST, instance=test_request, prefix='plastic_codes')
        input_file_formset = InputFileFormSet(request.POST, instance=test_request, prefix='input_files')
        quality_form = TestRequestQualityForm(request.POST, instance=quality_instance, prefix='quality')
        shipping_form = TestRequestShippingForm(request.POST, instance=shipping_instance, prefix='shipping')

        if (form.is_valid() and plastic_formset.is_valid() and
                input_file_formset.is_valid() and quality_form.is_valid() and
                shipping_form.is_valid()):
            try:
                with transaction.atomic():
                    form.save()
                    plastic_formset.save()
                    input_file_formset.save()
                    quality_form.save()
                    shipping_form.save()

                messages.success(request, f"Test Request {test_request.tvf_number} updated successfully!")
                return redirect('test_requests:detail', pk=test_request.pk)
            except Exception as e:
                messages.error(request, f"Error updating Test Request: {e}")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        # Initial GET request: populate forms with existing data
        form = TestRequestForm(instance=test_request)
        plastic_formset = PlasticCodeFormSet(instance=test_request, prefix='plastic_codes')
        input_file_formset = InputFileFormSet(instance=test_request, prefix='input_files')
        quality_form = TestRequestQualityForm(instance=quality_instance, prefix='quality')
        shipping_form = TestRequestShippingForm(instance=shipping_instance, prefix='shipping')

    context = {
        'form': form,
        'plastic_formset': plastic_formset,
        'input_file_formset': input_file_formset,
        'quality_form': quality_form,
        'shipping_form': shipping_form,
        'test_request': test_request, # Pass test_request for context in template
    }
    return render(request, 'test_requests/test_request_form.html', context)

@login_required
def test_request_pdf_view(request, pk):
    """
    View for generating a PDF of a single Test Request.
    """
    test_request = get_object_or_404(TestRequest.objects.select_related(
        'customer', 'project', 'tvf_initiator', 'tvf_type', 'tvf_environment', 'status', 'current_phase'
    ).prefetch_related(
        'plastic_codes_entries__plastic_code_lookup',
        'input_files_entries__pans',
        'quality_details__quality_sign_off_by', # Pre-fetch related user for quality
        'shipping_details__dispatch_method', # Pre-fetch related dispatch method
        'shipping_details__shipping_sign_off_by' # Pre-fetch related user for shipping
    ), pk=pk)

    context = {
        'test_request': test_request,
        'current_date': timezone.now(), # Pass current date for PDF
    }
    return render_to_pdf('test_requests/test_request_pdf_template.html', context)